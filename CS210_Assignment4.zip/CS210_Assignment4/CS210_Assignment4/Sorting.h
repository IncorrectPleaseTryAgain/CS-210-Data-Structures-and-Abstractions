#pragma once
#include "Array.h"
#include <chrono>

using namespace std::chrono;

class Sorting {
public:
	Sorting() {};
	~Sorting() {};

	void selectionSort(Array& arrayClass, steady_clock::time_point& begin, steady_clock::time_point& end);
	void bubbleSort(Array& arrayClass, steady_clock::time_point& begin, steady_clock::time_point& end);
	void heapSort(Array& arrayClass, steady_clock::time_point& begin, steady_clock::time_point& end);

private:

	void heapify(int*& myArray, const int& size, const int& index);

	void swap(int*& myArray, const int& index1, const int& index2);
};
