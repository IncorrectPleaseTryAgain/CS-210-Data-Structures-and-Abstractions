#pragma once
#include <iostream>
#include "Sorting.h"

using namespace std;

class Array {
public:
	Array(const int& size = 0) { this->size = size; myArray = new int[this->size]; };
	~Array() { clear(); }

	void setSize(const int& size) { this->size = size; myArray = new int[this->size]; }
	void setValue(const int& index, const int& value) { myArray[index] = value; }

	void print() {
		cout << "Display Array: " << endl;
		for (int i = 0; i < size - 1; i++) {
			cout << myArray[i] << ",";
		}
		cout << myArray[size - 1] << "\n" << endl;
	};

	void clear() { delete[] myArray; }

	friend class Sorting;
private:
	int* myArray;
	int size;

};
