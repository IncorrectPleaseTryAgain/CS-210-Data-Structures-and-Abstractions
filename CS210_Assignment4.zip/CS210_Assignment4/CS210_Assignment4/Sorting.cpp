#include "Sorting.h"
#include <iostream>
using namespace std;

void Sorting::selectionSort(Array& arrayClass, steady_clock::time_point& begin, steady_clock::time_point& end)
{	
	begin = steady_clock::now();
	unsigned int curMinIndex = 0;

	for (unsigned int i = 0; i < arrayClass.size - 1; i++) {
		curMinIndex = i;
		for (unsigned int j = i + 1; j < arrayClass.size; j++) {
			if (arrayClass.myArray[j] <= arrayClass.myArray[curMinIndex]) {
				curMinIndex = j;
			}
		}

		swap(arrayClass.myArray, i, curMinIndex);
	}

	end = steady_clock::now();
}

void Sorting::bubbleSort(Array& arrayClass, steady_clock::time_point& begin, steady_clock::time_point& end)
{
	begin = steady_clock::now();
	for (unsigned int i = 0; i < arrayClass.size - 1; i++) {
		for (unsigned int j = i + 1; j < arrayClass.size; j++) {
			if (arrayClass.myArray[j] < arrayClass.myArray[i]) {
				swap(arrayClass.myArray, i, j);
			}
		}
	}
	end = steady_clock::now();
}

void Sorting::heapSort(Array& arrayClass, steady_clock::time_point& begin, steady_clock::time_point& end)
{
	begin = steady_clock::now();

	for (int i = arrayClass.size / 2 - 1; i >= 0; i--)
		heapify(arrayClass.myArray, arrayClass.size, i);

	for (int i = arrayClass.size - 1; i >= 0; i--) {

		swap(arrayClass.myArray, 0, i);
		heapify(arrayClass.myArray, i, 0);
	}

	end = steady_clock::now();
}

void Sorting::heapify(int*& arr, const int& size, const int& index)
{
	int largest = index;
	int lc = 2 * index + 1;
	int rc = 2 * index + 2;

	if (lc < size && arr[lc] > arr[largest])
		largest = lc;

	if (rc < size && arr[rc] > arr[largest])
		largest = rc;

	if (largest != index) {
		swap(arr, index, largest);
		heapify(arr, size, largest);
	}
}

void Sorting::swap(int*& arr, const int& index1, const int& index2)
{
	int tempValue = arr[index1];
	arr[index1] = arr[index2];
	arr[index2] = tempValue;
}
