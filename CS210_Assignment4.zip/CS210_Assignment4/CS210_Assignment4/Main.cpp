/*
* Michael Steenkamp
* 200446289
* 
* CS210 - Assignment 4
* 26-11-2023
* 
* This program sorts an array and displays the time taken.
* Selection Sort
* Bubble Sort
* Heap Sort
*/

#include <iostream>
#include <iomanip>
#include <chrono>
#include "Sorting.h"
#include "Array.h"

using namespace std;
using namespace std::chrono;

/* GETTER FUNCTIONS */
int getIntiger();
void getOption(int& option);

/* SETTER FUNCTIONS */
void initializeArray(Array& myArray);

/* EXECUTION FUNCTIONS */
bool executeOption(const int& option, Sorting& Sort, Array& myArray);

/* DISPLAY FUNCTIONS */
void displayOptions();

/* HELPER FUNCTIONS */
void Helper_ClearBuffer();


int main() {
	Sorting Sort;
	Array myArray;
	int option = -1;

	initializeArray(myArray);

	do {
		displayOptions();
		getOption(option);

	} while (executeOption(option, Sort, myArray));

	return 0;
}

int getIntiger()
{
	int value;
	cin >> value;
	while (cin.fail()) {
		Helper_ClearBuffer();
		cout << "\nError: Non-Intiger Input...\n" << endl;

		cout << "Re-attempt Intiger Input: ";
		cin >> value;
	}

	return value;
}

void getOption(int& option)
{
	cout << "Please Enter Option: ";
	option = getIntiger();
	
	while (option < 1 || option > 6) {
		cout << "\nError: Invalid Option...\n" << endl;

		cout << "Please Enter Option: ";
		option = getIntiger();
	}
}

void initializeArray(Array& myArray)
{
	myArray.clear();

	int size = 0;
	cout << "Enter Number of Elements: ";
	size = getIntiger();

	while (size < 1) {
		cout << "\nError: Positive Input Required...\n" << endl;

		cout << "Enter Number of Elements: ";
		size = getIntiger();
	}

	myArray.setSize(size);

	int item = 0;
	for (int i = 0; i < size; i++) {
		cout << "Enter Element [" << i << "]: ";
		item = getIntiger();
		myArray.setValue(i, item);
	}
}

bool executeOption(const int& option, Sorting& Sort, Array& myArray)
{
	steady_clock::time_point begin;
	steady_clock::time_point end;

	if (option == 1) {
		initializeArray(myArray);
		return true;
	}
	else if (option == 2) {

		cout << "\nSelections Sort: " << endl;
		Sort.selectionSort(myArray, begin, end);
	}
	else if (option == 3) {
		cout << "\nBubble Sort: " << endl;
		Sort.bubbleSort(myArray, begin, end);
	}
	else if (option == 4) {
		cout << "\nHeap Sort: " << endl;
		Sort.heapSort(myArray, begin, end);
	}
	else if (option == 5) {
		myArray.print();
		return true;
	}
	else{ 
		cout << "Terminating Program..." << endl;
		return false;
	}

	myArray.print();
	cout << "Time elapsed = " << (double)duration_cast<milliseconds>(end - begin).count() << " ms\n" << std::endl;

	return true;
}

void displayOptions()
{
	cout << "Options: " << endl;
	cout << "1: Create Array" << endl;
	cout << "2: Selection Sort" << endl;
	cout << "3: Bubble Sort" << endl;
	cout << "4: Heap Sort" << endl;
	cout << "5: Display Array" << endl;
	cout << "6: End Program" << endl;
}

void Helper_ClearBuffer()
{
	cin.clear();
	cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
}
