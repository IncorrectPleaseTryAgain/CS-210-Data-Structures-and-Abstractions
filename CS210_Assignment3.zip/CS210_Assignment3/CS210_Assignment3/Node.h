#pragma once

struct Node {
	Node(const int& data) :
		data(data),
		parent(nullptr),
		leftChild(nullptr),
		rightChild(nullptr) {};

	~Node() {
		data = -1;
		parent = leftChild = rightChild = nullptr;
	}

	int data;
	Node* parent;
	Node* leftChild;
	Node* rightChild;

private:
};