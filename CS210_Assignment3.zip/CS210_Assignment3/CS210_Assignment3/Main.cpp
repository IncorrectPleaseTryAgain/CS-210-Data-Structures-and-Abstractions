/*
* Michael Steenkamp
* 200446289
* 
* CS 210 - Assignment 3
* 
* This program takes user input for intigers and then inserts into
* binary search tree.
* 
*/

#include <iostream>
#include "BST.h"

using namespace std;

void HELPER_CLEAR_BUFFER();

void insertMultipleItems(BST& bst, int numItems = 1);
bool insertItem(BST& bst);
bool removeItem(BST& bst);

int getInitialSize();
int getIntigerInput();

bool getOption(int& option);
bool executeOption(BST& bst, const int& option);

void displayOptions();

int main() {
	
	BST bst;

	// Initial Setup
	insertMultipleItems(bst, getInitialSize());

	// clear terminal
	system("CLS");

	// Main Loop
	int option = 0;
	do {
		displayOptions();

		while (!getOption(option)) { cout << "Invalid Option...\n" << endl; }

	} while (executeOption(bst, option));


	cout << "Program Terminated." << endl;

	return 0;
}

void HELPER_CLEAR_BUFFER()
{
	cin.clear();
	cin.ignore(numeric_limits<streamsize>::max(), '\n');
}

void insertMultipleItems(BST& bst, int numItems)
{
	int input = 0;
	unsigned int count = 0;

	while (count < numItems) {
		insertItem(bst) ? count++ : count;
	}
}

bool insertItem(BST& bst)
{
	try {
		bst.insert(getIntigerInput());
		cout << "Item Itserted..." << endl;
		return true;
	}
	catch (Exception_Full) {
		cout << "BST Full...\n" << endl;
		return false;
	}
	catch (Exception_ItemAlreadyExists) {
		cout << "Item Already Exists...\n" << endl;
		return false;
	}
}

bool removeItem(BST& bst)
{
	try {
		bst.remove(getIntigerInput());
		cout << "Item Removed..." << endl;
		return true;
	}
	catch (Exception_Empty) {
		cout << "BST Empty...\n" << endl;
		return false;
	}
	catch (Exception_ItemNotFound) {
		cout << "Item Not Found...\n" << endl;
		return false;
	}
}

int getInitialSize()
{
	int initialSize = 0;

	do {
		cout << "How many intigers do you want (minimum: 1): ";
		cin >> initialSize;

		if (initialSize > 0) {
			return initialSize;
		}
		else {
			cout << "Invalid Input...\n" << endl;
			HELPER_CLEAR_BUFFER();
		}

	} while (true);
}

int getIntigerInput()
{
	int input = 0;

	do{
		cout << "Please enter intiger: ";
		cin >> input;

		if (cin.fail()) {
			cout << "Invalid Input...\n" << endl;
			HELPER_CLEAR_BUFFER();
		}
		else {
			return input;
		}

	} while (true);
}

bool getOption(int& option)
{
	cout << "Please Enter Option Selection: ";
	cin >> option;

	if (cin.fail()) { HELPER_CLEAR_BUFFER(); return false; }

	if (option >= 1 && option <= 7) { return true; }

	return false;
}

bool executeOption(BST& bst, const int& option)
{

	// Insert
	if (option == 1) {
		insertItem(bst);
	}
	// Remove
	else if (option == 2) {
		removeItem(bst);
	}
	// Inorder
	else if (option == 3) {
		bst.displayInorder();
	}
	// Preorder
	else if (option == 4) {
		bst.displayPreorder();
	}
	// Postorder
	else if (option == 5) {
		bst.displayPostorder();
	}
	// Clear
	else if (option == 6) {
		bst.clear();
	}
	// Exit
	else {
		return false;
	}

	cout << '\n';
	return true;
}

void displayOptions()
{
	cout << "Options:" << endl;
	cout << "1: Insert new item" << endl;
	cout << "2: Delete item" << endl;
	cout << "3: Print In-order" << endl;
	cout << "4: Print Pre-order" << endl;
	cout << "5: Print Post-order" << endl;
	cout << "6: Clear BST" << endl;
	cout << "7: Exit Program" << endl;
	cout << '\n';
}
