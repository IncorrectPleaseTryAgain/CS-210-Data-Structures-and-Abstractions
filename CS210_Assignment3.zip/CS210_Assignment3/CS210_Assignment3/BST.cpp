#include "BST.h"
#include <iostream>

using namespace std;

/* PUBLIC */
void BST::insert(const int& toInsert)
{
	if (isFull()) { throw Exception_Full(); }
	if (isEmpty()) { root = new Node(toInsert); return; }

	Node* temp = root;
	while (temp->data != toInsert) {
		
		if (toInsert < temp->data) {
			if (temp->leftChild == nullptr) {
				temp->leftChild = new Node(toInsert);
				temp->leftChild->parent = temp;
				return;
			}

			temp = temp->leftChild;
		}
		else {
			if (temp->rightChild == nullptr) {
				temp->rightChild = new Node(toInsert);
				temp->rightChild->parent = temp;
				return;
			}

			temp = temp->rightChild;
		}
	}

	throw Exception_ItemAlreadyExists();
}

void BST::remove(const int& toRemove)
{
	if (isEmpty()) { throw Exception_Empty(); }
	
	Node* removeNode = find(root, toRemove);

	if (removeNode == nullptr) { throw Exception_ItemNotFound(); }

	// Case 1 : 0 Child
	if (!removeNode->leftChild && !removeNode->rightChild) {
		if (removeNode == root) { delete removeNode; root = nullptr; return; }

		if (removeNode->parent->leftChild == removeNode) { removeNode->parent->leftChild = nullptr; delete removeNode; return; }
		if (removeNode->parent->rightChild == removeNode) { removeNode->parent->rightChild = nullptr; delete removeNode; return; }
	}

	// Case 2 : 1 Child
	// Left
	if (removeNode->leftChild && !removeNode->rightChild) {
		if (removeNode == root) { root = removeNode->leftChild;  root->parent = nullptr; delete removeNode; return; }

		removeNode->parent->leftChild == removeNode ? removeNode->parent->leftChild = removeNode->leftChild : removeNode->parent->rightChild = removeNode->leftChild;

		removeNode->leftChild->parent = removeNode->parent;
		delete removeNode;
		return;
	}
	// Right
	if (!removeNode->leftChild && removeNode->rightChild) {
		if (removeNode == root) { root = removeNode->rightChild;  root->parent = nullptr; delete removeNode; return; }

		removeNode->parent->leftChild == removeNode ? removeNode->parent->leftChild = removeNode->rightChild : removeNode->parent->rightChild = removeNode->rightChild;

		removeNode->rightChild->parent = removeNode->parent;
		delete removeNode;
		return;
	}

	// Case 3 : 2 Child
	if (removeNode->leftChild && removeNode->rightChild) {

		Node* minNode = removeNode->rightChild;

		while (minNode->leftChild) { minNode = minNode->leftChild; }

		removeNode->data = minNode->data;

		minNode->parent == removeNode ? removeNode->rightChild = minNode->rightChild : minNode->parent->leftChild = minNode->rightChild;

		if (minNode->rightChild) {
			minNode->rightChild->parent = minNode->parent;
		}

		delete minNode;
		return;

	}
}

void BST::clear()
{
	cout << "Clearing BST..." << endl;

	while (root) {
		remove(root->data);
	}

	cout << "Success..." << endl;
}

void BST::displayInorder()
{
	cout << "In-order Display:" << endl;

	if (!isEmpty()) { inorder(root); cout << '\n'; }
	else { cout << "*** Empty ***" << endl; }
}

void BST::displayPreorder()
{
	cout << "Pre-order Display:" << endl;
	if (!isEmpty()) { preorder(root); cout << '\n'; }
	else { cout << "*** Empty ***" << endl; }
}

void BST::displayPostorder()
{
	cout << "Post-order Display:" << endl;
	if (!isEmpty()) { postorder(root);  cout << '\n'; }
	else { cout << "*** Empty ***" << endl; }
}


/* PRIVATE */
bool BST::isEmpty()
{
	return (root == nullptr);
}

bool BST::isFull()
{
	try {
		Node* temp = new Node(0);
		delete temp;
		return false;
	}
	catch (...) {
		return true;
	}
}

void BST::inorder(Node*& start)
{
	if (start->leftChild) {
		inorder(start->leftChild);
	}

	cout << " " << start->data;

	if (start->rightChild) {
		inorder(start->rightChild);
	}
}

void BST::preorder(Node*& start)
{
	cout << " " << start->data;

	if (start->leftChild) {
		preorder(start->leftChild);
	}

	if (start->rightChild) {
		preorder(start->rightChild);
	}
}

void BST::postorder(Node*& start)
{

	if (start->leftChild) {
		postorder(start->leftChild);
	}

	if (start->rightChild) {
		postorder(start->rightChild);
	}

	cout << " " << start->data;
}

Node*& BST::find(Node*& start, const int& toFind)
{
	if (start == nullptr || start->data == toFind) { return start; }

	toFind < start->data ? find(start->leftChild, toFind) : find(start->rightChild, toFind);
}