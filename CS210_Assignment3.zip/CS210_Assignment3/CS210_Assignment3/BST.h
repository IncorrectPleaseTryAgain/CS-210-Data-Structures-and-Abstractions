#pragma once
#include "Node.h"

using namespace std;

class Exception_Full {};
class Exception_Empty {};
class Exception_ItemAlreadyExists {};
class Exception_ItemNotFound {};

class BST {
public:
	BST() : root(nullptr) {};
	~BST() { clear(); }

	void insert(const int& toInsert);
	void remove(const int& toRemove);
	void clear();

	void displayInorder();
	void displayPreorder();
	void displayPostorder();

private:
	Node* root;

	bool isEmpty();
	bool isFull();

	void inorder(Node*& start);
	void preorder(Node*& start);
	void postorder(Node*& start);

	Node*& find(Node*& start, const int& toFind);
};
