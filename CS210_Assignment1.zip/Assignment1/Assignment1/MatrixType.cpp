#include "MatrixType.h"

#include <iostream>

using namespace std;

MatrixType::MatrixType()
{
	for (unsigned int r = 0; r < MAX_ROWS; r++) {
		for (unsigned int c = 0; c < MAX_COLS; c++) {
			values[r][c] = -1;
		}
	}

	numRows = 0;
	numCols = 0;
}

void MatrixType::SetSize(int rowSize, int colSize)
{
	numRows = rowSize;
	numCols = colSize;
}

void MatrixType::StoreItem(int item, int row, int col)
{
	values[row][col] = item;
}

void MatrixType::Add(MatrixType otherOperand, MatrixType& result)
{
	result.SetSize(numRows, numCols);

	for (unsigned int r = 0; r < numRows; r++) {
		for (unsigned int c = 0; c < numCols; c++) {
			result.values[r][c] = values[r][c] + otherOperand.values[r][c];
		}
	}
}

void MatrixType::Sub(MatrixType otherOperand, MatrixType& result)
{
	result.SetSize(numRows, numCols);

	for (unsigned int r = 0; r < numRows; r++) {
		for (unsigned int c = 0; c < numCols; c++) {
			result.values[r][c] = values[r][c] - otherOperand.values[r][c];
		}
	}
}

void MatrixType::Mult(MatrixType otherOperand, MatrixType& result)
{
	MatrixType temp;
	temp.SetSize(numRows, otherOperand.numCols);

	int dotProduct;
	unsigned short int curTempRow = 0;
	unsigned short int curTempCol = 0;

	// loop first matrix row
	for (unsigned short int firstMatrixRow = 0; firstMatrixRow < numRows; firstMatrixRow++) {
		// loop second matrix column
		for (unsigned short int secondMatrixCol = 0; secondMatrixCol < otherOperand.numCols; secondMatrixCol++) {

			dotProduct = 0;

			// loop second matrix row
			for (unsigned short int secondMatrixRow = 0; secondMatrixRow < otherOperand.numRows; secondMatrixRow++) {
				dotProduct += (values[firstMatrixRow][secondMatrixRow] * otherOperand.values[secondMatrixRow][secondMatrixCol]);
			}

			temp.StoreItem(dotProduct, firstMatrixRow, secondMatrixCol);
		}

	}

	result = temp;
}

void MatrixType::Print()
{
	for (unsigned int r = 0; r < numRows; r++) {
		for (unsigned int c = 0; c < numCols; c++) {
			cout << values[r][c] << " ";
		}
		cout << '\n';
	}
}

bool MatrixType::AddSubCompatible(MatrixType otherOperand)
{
	if (numRows != otherOperand.numRows || numCols != otherOperand.numCols) {
		return false;
	}
	return true;
}

bool MatrixType::MultCompatible(MatrixType otherOperand)
{
	if (numCols != otherOperand.numRows) {
		return false;
	}
	return true;
}
