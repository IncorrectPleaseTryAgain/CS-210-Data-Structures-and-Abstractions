/*
name: Michael Steenkamp
ID: 200446289
course: CS 210

Assignment 1

This program allows the user to create matrices and perform certain matrix operations.
*/

#include <iostream>
#include <string>
#include <limits> // cin.ignore | not required for all compilers

#include "MatrixType.h"

using namespace std;

/*EXECUTE FUNCTION*/
void executeOption(MatrixType* &matrixList);

/*HELPER FUNCTIONS*/
void HELPER_clearBuffer();
void HELPER_printErrorMessage(const string& message);
bool HELPER_isWholeNumber(const string& stringToCheck);
bool HELPER_isInputValidIntiger(const string& input);
bool HELPER_isInRange(const int& input, const int& min, const int& max); // Inclusive | >= && <=
bool HELPER_isListEmpty();
bool HELPER_isListFull();

/*DISPLAY FUNCTIONS*/
void displayOptions();
void displayAddRules();
void displaySubRules();
void displayMultRules();

/*GET & SET FUNCTIONS*/
void setMatrixValues(MatrixType* &matrixList, const int& numRows, const int& numCols);
bool getOption();
bool getOperationVariables(int& A, int& B, int& C);
int getMatrixIndex();
int getNumRows();
int getNumCols();
int getMatrixValues(const int& curRow, const int& curCol);

/*GLOBAL VARIABLES*/
int numMatrices = 0;
int userOption = 0;

const int MAX_NUM_MATRICES = 10;
const int NUMBER_OF_OPTIONS = 7;
const int INPUT_CANCEL = -1;

int main() 
{
	MatrixType* matrixList = new MatrixType[MAX_NUM_MATRICES];

	/*
	* While the user hasn't decided to end the program,
	* keep asking for option and execute selected option
	*/
	do {
		do {
			displayOptions();
		} while (!getOption());

		executeOption(matrixList);

	} while (userOption != NUMBER_OF_OPTIONS); // End Program - Option {NUMBER_OF_OPTIONS}

	delete[] matrixList;
	return 0;
}

/*EXECUTE FUNCTION*/
void executeOption(MatrixType* &matrixList)
{
	// Option 1 - Create Matrix
	if (userOption == 1) {

		if (HELPER_isListFull()) {
			HELPER_printErrorMessage("Matrix list is full");
			return;
		}

		cout << '\n';
		cout << "Create Matrix" << endl;

		int numRows = getNumRows();
		if (numRows == INPUT_CANCEL) { system("cls"); return; }

		int numCols = getNumCols();
		if (numCols == INPUT_CANCEL) { system("cls"); return; }

		matrixList[numMatrices].SetSize(numRows, numCols);

		setMatrixValues(matrixList, numRows, numCols);

		cout << '\n';
		cout << "Matrix Created: " << endl;
		matrixList[numMatrices].Print();
		cout << '\n';

		numMatrices++;
	}
	// Option 2 - Add Matrices
	else if (userOption == 2) {

		if (HELPER_isListEmpty()) { 
			HELPER_printErrorMessage("Matrix list is empty");
			return;	
		}

		cout << '\n';
		cout << "Add Matrices" << endl;
		cout << '\n';

		displayAddRules();

		int A, B, C = 0; // C = A + B
		if (getOperationVariables(A, B, C) == false) { return; } // False | user input = INPUT_CANCEL

		if (matrixList[A].AddSubCompatible(matrixList[B]) == false) {
			HELPER_printErrorMessage("Invalid Input | A and B not compatible");
			return;
		}

		matrixList[A].Add(matrixList[B], matrixList[C]);

		cout << '\n';
		cout << "Matrix " << C << " = " << "Matrix " << A << " + " << "Matrix " << B << endl;
		cout << '\n';
	}
	// Option 3 - Subtract Matrices
	else if (userOption == 3) {

		if (HELPER_isListEmpty()) { 
			HELPER_printErrorMessage("Matrix list is empty");
			return;
		}

		cout << '\n';
		cout << "Subtract Matrices" << endl;
		cout << '\n';

		displaySubRules();

		int A, B, C = 0; // C = A - B
		if (getOperationVariables(A, B, C)  == false) { return; }  // False | user input = INPUT_CANCEL

		if (matrixList[A].AddSubCompatible(matrixList[B]) == false) {
			HELPER_printErrorMessage("Invalid Input | A and B not compatible");
			return;
		}

		matrixList[A].Sub(matrixList[B], matrixList[C]);

		cout << '\n';
		cout << "Matrix " << C << " = " << "Matrix " << A << " - " << "Matrix " << B << endl;
		cout << '\n';
	}
	// Option 4 - Multiply Matrices
	else if (userOption == 4) {

		if (HELPER_isListEmpty()) {	
			HELPER_printErrorMessage("Matrix list is empty");
			return;	
		}

		cout << '\n';
		cout << "Multiply Matrices" << endl;
		cout << '\n';

		displayMultRules();

		int A, B, C = 0; // C = A * B
		if (getOperationVariables(A, B, C) == false) { return; }  // False | user input = INPUT_CANCEL

		if (matrixList[A].MultCompatible(matrixList[B]) == false) {
			HELPER_printErrorMessage("Invalid Input | A and B not compatible");
			return;
		}

		matrixList[A].Mult(matrixList[B], matrixList[C]);

		cout << '\n';
		cout << "Matrix " << C << " = " << "Matrix " << A << " * " << "Matrix " << B << endl;
		cout << '\n';
	}
	// Option 5 - Print Matrix
	else if (userOption == 5) {

		if (HELPER_isListEmpty()) {
			HELPER_printErrorMessage("Matrix list is empty");
			return;
		}

		cout << '\n';
		cout << "Print Matrix" << endl;
		cout << "(cancel: -1)" << endl;

		int index = getMatrixIndex();
		if (index == INPUT_CANCEL) { return; }

		matrixList[index].Print();
		cout << '\n';
	}
	// Option 6 - Reset Terminal
	else if (userOption == 6) {
		system("cls");
	}
	// Option 7 - End Program
	else if (userOption == 7) {
		cout << '\n';
		cout << "Terminating Program..." << endl;
		cout << '\n';
	}
	// Default Execution
	else {
		HELPER_printErrorMessage("Something went wrong!");
	}
}

/*HELPER FUNCTIONS*/
void HELPER_clearBuffer()
{
	cin.clear();
	cin.ignore(numeric_limits<streamsize>::max(), '\n');
}

void HELPER_printErrorMessage(const string& message)
{
	cout << '\n';
	cout << "\t------" << endl;
	cout << "\tError: " << message << endl;
	cout << "\t------" << endl;
	cout << '\n';
}

bool HELPER_isWholeNumber(const string& stringToCheck)
{
	int i = 0;

	/*
	* Let x be any intiger
	* Let y be any non-intiger
	* 
	* Return:
	*	True: -x , x
	*	False: - , y
	*/

	// Check Input: - , -x
	if (stringToCheck[0] == '-') {
		if (stringToCheck.length() > 1) {
			i++;
		}
		else {
			return false;
		}
	}

	// Check Input: x , y 
	while (i < stringToCheck.length()) {
		if (!isdigit(stringToCheck[i])) {
			return false;
		}
		i++;
	}

	return true;
}

bool HELPER_isInputValidIntiger(const string& input)
{
	if (input.length() > 0) {
		if (HELPER_isWholeNumber(input)) {
			return true;
		}
	}

	return false;
}

bool HELPER_isInRange(const int& input, const int& min, const int& max)  // Inclusive | >= && <=
{
	if (input >= min && input <= max) {
		return true;
	}

	return false;
}

bool HELPER_isListEmpty()
{
	return numMatrices == 0;
}

bool HELPER_isListFull()
{
	return numMatrices == MAX_NUM_MATRICES;
}

/*DISPLAY FUNCTIONS*/
void displayOptions()
{
	cout << "Current number of matrices: " << numMatrices << endl;
	cout << "Please Choose From One of The Following Options:" << endl;
	cout << "1 - Create Matrix" << endl;
	cout << "2 - Add Matrices" << endl;
	cout << "3 - Subtract Matrices" << endl;
	cout << "4 - Multiply Matrices" << endl;
	cout << "5 - Print Matrix" << endl;
	cout << "6 - Reset Terminal" << endl;
	cout << "7 - End Program" << endl;
}

void displayAddRules()
{
	cout << '\n';
	cout << "Rules:" << endl;
	cout << "Matrices must have the same dimentions in order to be added" << endl;
	cout << '\n';
	cout << "C = A + B" << endl;
	cout << "let A be the index of the frist matrix addend" << endl;
	cout << "let B be the index of the second matrix addend" << endl;
	cout << "let C be the index of the sum of A and B to be stored" << endl;
}

void displaySubRules()
{
	cout << '\n';
	cout << "Rules:" << endl;
	cout << "Matrices must have the same dimentions in order to be subtracted" << endl;
	cout << '\n';
	cout << "C = A - B" << endl;
	cout << "let A be the index of the frist matrix subtracted" << endl;
	cout << "let B be the index of the second matrix subtracted" << endl;
	cout << "let C be the index of the difference of A and B to be stored" << endl;
}

void displayMultRules()
{
	cout << '\n';
	cout << "Rules:" << endl;
	cout << "The number of columns of the matrix A must equal the number of rows of matrix B" << endl;
	cout << '\n';
	cout << "C = A x B" << endl;
	cout << "let A be the index of the frist matrix multiplied" << endl;
	cout << "let B be the index of the second matrix multiplied" << endl;
	cout << "let C be the index of the product of A and B to be stored" << endl;
}

/*GET & SET FUNCTIONS*/
void setMatrixValues(MatrixType*& matrixList, const int& numRows, const int& numCols)
{
	int value = 0;

	cout << '\n';
	cout << "Note: Only Whole Number Accepted (...,-1,0,1,...)" << endl;
	cout << "Please enter values [row][col]:" << endl;

	// For each index [r][c] - get & set value
	for (unsigned int r = 0; r < numRows; r++) {
		for (unsigned int c = 0; c < numCols; c++) {
			value = getMatrixValues(r, c);
			matrixList[numMatrices].StoreItem(value, r, c);
		}
	}
}

bool getOption()
{
	string input = "";

	cout << "Please enter option (1-" << NUMBER_OF_OPTIONS << "): ";
	getline(cin, input);

	/*
	* Validate Input:
	*	Input is an intiger
	*	Input is in range [1 - number of options]
	*/
	if (HELPER_isInputValidIntiger(input)) {
		userOption = stoi(input);
		if (HELPER_isInRange(userOption, 1, NUMBER_OF_OPTIONS)) {
			return true;
		}
	}

	HELPER_printErrorMessage("Invalid Option Selection");

	return false;
}

bool getOperationVariables(int& A, int& B, int& C)
{
	cout << "\n-------- A --------" << endl;;
	A = getMatrixIndex();
	if (A == INPUT_CANCEL) { system("cls"); return false; }

	cout << "\n-------- B --------" << endl;;
	B = getMatrixIndex();
	if (B == INPUT_CANCEL) { system("cls"); return false; }

	cout << "\n-------- C --------" << endl;;
	C = getMatrixIndex();
	if (C == INPUT_CANCEL) { system("cls"); return false; }

	return true;
}

int getMatrixIndex()
{
	string input = "";

	do {
		cout << "Please enter index (cancel: -1): ";
		getline(cin, input);

		/*
		* Validate Input:
		*	Input is an intiger
		*	Input is in range [-1 - (number of matrices - 1)]
		*/
		if (HELPER_isInputValidIntiger(input)) {
			int index = stoi(input);
			if (HELPER_isInRange(index, -1, numMatrices - 1)) {
				return index;
			}
		}

		HELPER_printErrorMessage("Invalid Input | Index out of range");

	} while (true);
}

int getNumRows()
{
	string input = "";

	// GET INPUT - ROWS
	do {
		cout << '\n';
		cout << "Min number of rows: 1" << endl;
		cout << "Max number of rows: " << MAX_ROWS << endl;
		cout << "Please enter number of rows (cancel: -1): ";
		getline(cin, input);

		/*
		* Validate Input:
		*	Input is an intiger
		*	Input is in range [1 - max rows]  OR Input = input cancel
		*/
		if (HELPER_isInputValidIntiger(input)) {
			int numRows = stoi(input);
			if (HELPER_isInRange(numRows, 1, MAX_ROWS) || numRows == INPUT_CANCEL) {
				return numRows;
			}
		}

		HELPER_printErrorMessage("Invalid Input | Number of Rows");

	} while (true);
}

int getNumCols()
{
	string input = "";

	// GET INPUT - COLS
	do {
		cout << '\n';
		cout << "Min number of columns: 1" << endl;
		cout << "Max number of columns: " << MAX_COLS << endl;
		cout << "Please enter number of columns (cancel: -1): ";
		getline(cin, input);

		/*
		* Validate Input:
		*	Input is an intiger
		*	Input is in range [1 - max columns]  OR Input = input cancel
		*/
		if (HELPER_isInputValidIntiger(input)) {
			int numCOls = stoi(input);
			if (HELPER_isInRange(numCOls, 1, MAX_COLS) || numCOls == INPUT_CANCEL) {
				return numCOls;
			}
		}

		HELPER_printErrorMessage("Invalid Input | Number of Columns");

	} while (true);
}

int getMatrixValues(const int& curRow, const int& curCol)
{
	string input = "";

	while (true) {
		cout << "[" << curRow << "]" << "[" << curCol << "]: ";
		getline(cin, input);

		/*
		* Validate Input:
		*	Input is at least 1 character
		*	Input is a whole number
		*/
		if (input.length() > 0 && HELPER_isWholeNumber(input)) {
			int value = stoi(input);
			return value;
		}
		else {
			HELPER_printErrorMessage("Invalid Input | Value");
		}
	}
}
