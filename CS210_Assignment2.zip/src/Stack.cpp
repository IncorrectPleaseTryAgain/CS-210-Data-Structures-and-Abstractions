#include "Stack.h"

#include <iostream>

Stack::Stack(const unsigned int& STACK_LENGTH)
{
	std::cout << "Creating Stack...\n";

	stackList = new char[STACK_LENGTH];
	maxLength = STACK_LENGTH;
	top = -1;
}

Stack::~Stack()
{
	std::cout << "Deleting Stack...\n";
	delete[] stackList;
}

bool Stack::push(const char& item)
{
	if (isFull()) { return false; }

	top++;
	stackList[top] = item;

	return true;
}

bool Stack::pop()
{
	if (isEmpty()) { return false; }

	top--;
	return true;
}

char Stack::getTop()
{
	if (isEmpty()) { return false; }

	return stackList[top];
}

bool Stack::isFull()
{
	return top == maxLength - 1;
}

bool Stack::isEmpty()
{
	return top == -1;
}
