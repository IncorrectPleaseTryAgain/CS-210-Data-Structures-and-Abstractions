/*
* Michael Steenkamp
* 200446289
*
* CS 210
*
* Assignment 2
*
* This program converts infix expressions to postfix.
*
*/

#include <iostream>
#include <string>

#include "Stack.h"


/* MAIN PROGRAM FUNCTIONS */
bool getInfixExpression(std::string& expression);
bool convertInfixToPostfix(const std::string& infixExpression, std::string& postfixExpression);

/* DISPLAY FUNCTIONS */
void displayRules();
void displayResults(const std::string& infixExpression, const std::string& postfixExpression);

/* HELPER FUNCTIONS */
bool Helper_isInfixExpressionValid(const std::string& infixExpression);
bool Helper_isOperator(const char& c);
bool Helper_isOperand(const char& c);
bool Helper_isPrecedenceHigherOrEqual(const char& main, const char& comparitor);

int main() {
	std::string infixExpression = "";
	std::string postfixExpression = "";

	do {
		displayRules();

		if (!getInfixExpression(infixExpression)) {
			std::cout << "\nInvalid Expression..." << std::endl;
			std::cout << "---------------------------------------" << std::endl;
		}
		else {
			break;
		}

	} while (true);

	if (!convertInfixToPostfix(infixExpression, postfixExpression)) { std::cout << "Error: Something Went Wrong!"; return -1; }

	displayResults(infixExpression, postfixExpression);

	return 0;
}

/* MAIN PROGRAM FUNCTIONS */
bool getInfixExpression(std::string& infixExpression)
{
	std::cout << "Please Enter Infix Expression: ";
	getline(std::cin, infixExpression);

	return Helper_isInfixExpressionValid(infixExpression);
}

bool convertInfixToPostfix(const std::string& infixExpression, std::string& postfixExpression)
{
	Stack myStack(infixExpression.length());

	for (unsigned int i = 0; i < infixExpression.length(); i++) {

		// Check Operand
		if (Helper_isOperand(infixExpression[i])) {
			postfixExpression += infixExpression[i];
		}

		// Check Operator
		else if (Helper_isOperator(infixExpression[i])) {
			while (!myStack.isEmpty() && Helper_isPrecedenceHigherOrEqual(myStack.getTop(), infixExpression[i])) {
				postfixExpression += myStack.getTop();
				myStack.pop();
			}

			myStack.push(infixExpression[i]);
		}

		// Check Open Bracket
		else if (infixExpression[i] == '('){
			myStack.push(infixExpression[i]);
		}

		// Check Close Bracket
		else if (infixExpression[i] == ')') {
			while (myStack.getTop() != '(') {
				postfixExpression += myStack.getTop();
				myStack.pop();
			}

			myStack.pop();
		}
	}

	// Empty Stack
	while (!myStack.isEmpty()) {
		postfixExpression += myStack.getTop();
		myStack.pop();
	}

	return true;
}

/* DISPLAY FUNCTIONS */
void displayRules()
{
	std::cout << "Rules: \n\n";
	std::cout << "Brackets () Allowed" << std::endl;
	std::cout << "Valid Operators: + , - , * , /" << std::endl;
	std::cout << "Valid Operands: a-z , A-Z" << std::endl;
	std::cout << "Operators cannot exist next to each other" << std::endl;
	std::cout << "Operands cannot exist next to each other" << std::endl;
	std::cout << "Every open parenthesis needs a closing parenthesis" << std::endl;

	std::cout << "\n\nExamples:\n\n";
	std::cout << "Valid: A+B , (A+B) , etc." << std::endl;
	std::cout << "Invalid: AB , A+-B , (A+B , etc." << std::endl;
	std::cout << '\n';
}

void displayResults(const std::string& infixExpression, const std::string& postfixExpression)
{
	std::cout << "\nResults:" << std::endl;
	std::cout << "Infix: " << infixExpression << std::endl;
	std::cout << "Postfix: " << postfixExpression << std::endl;
}

/* HELPER FUNCTIONS */
bool Helper_isInfixExpressionValid(const std::string& infixExpression)
{
	if (infixExpression.length() == 0) { return false; }
	if (Helper_isOperator(infixExpression[0])) { return false; }

	int numSingleParenthesis = 0;
	unsigned int numOperands = 0;

	for (unsigned int i = 0; i < infixExpression.length(); i++) {
		
		// Check parenthesis
		if (infixExpression[i] == '(') {
			if (i == infixExpression.length() - 1) { return false; }
			numSingleParenthesis++;
		}
		else if (infixExpression[i] == ')') {
			if (numSingleParenthesis < 1) { return false; }
			numSingleParenthesis--;
		}

		// Check alphanumeric
		else if (Helper_isOperand(infixExpression[i])) {

			numOperands++;


			if (i < infixExpression.length() - 1) {
				// Check next not alpha
				if (isalpha(infixExpression[i + 1])) { return false; }
			}
		}

		// Check operator
		else if (Helper_isOperator(infixExpression[i])) {

			if (i < infixExpression.length() - 1) {
				// Check next not operator
				if (Helper_isOperator(infixExpression[i + 1])) { return false; }
			}
		}

		// Check space character
		else if (infixExpression[i] == ' ') {
			continue;
		}

		else { return false; }
	}

	return (numSingleParenthesis == 0 && numOperands > 0);
}

bool Helper_isOperator(const char& c)
{
	return (c == '*' || c == '/' || c == '+' || c == '-');
}

bool Helper_isOperand(const char& c)
{
	return isalpha(c);
}

bool Helper_isPrecedenceHigherOrEqual(const char& main, const char& comparitor) // 'main' has precedence over 'comparitor' 
{
	// Check equal
	if ((main == '+' && comparitor == '-') || 
		(main == '-' && comparitor == '+') ||
		(main == '*' && comparitor == '/') ||
		(main == '/' && comparitor == '*') ||
		(main == comparitor)) {
		return true;
	}

	// Check not equal
	if ((main == '*' || main == '/') &&
		(comparitor == '+' || comparitor == '-')) {
		return true;
	}

	return false;
}
