#pragma once

class Stack {
public:
	Stack(const unsigned int& STACK_LENGTH);
	~Stack();

	bool push(const char& item);
	bool pop();
	char getTop();

	bool isFull();
	bool isEmpty();

private:
	char* stackList;
	unsigned int top;
	unsigned int maxLength;
};